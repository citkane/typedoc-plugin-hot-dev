import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureOptional extends YafHTMLElement<JSONOutput.OptionalType> {
    onConnect(): void;
}
