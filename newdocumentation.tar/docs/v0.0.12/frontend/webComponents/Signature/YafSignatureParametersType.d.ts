import { YafTypeParameterReflection } from '../../../types/types.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafSignatureParametersType extends YafHTMLElement<YafTypeParameterReflection[] | undefined> {
    onConnect(): void;
}
