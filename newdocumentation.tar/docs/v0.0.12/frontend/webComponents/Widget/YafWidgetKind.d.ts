import { YafHTMLElement } from '../../index.js';
export declare class YafWidgetKind extends YafHTMLElement<{
    kind: string;
}> {
    onConnect(): void;
}
